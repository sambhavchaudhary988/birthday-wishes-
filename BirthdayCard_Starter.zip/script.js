// Starter script
console.log("Happy Birthday Aunty ❤️");
// Put your full JavaScript here.
