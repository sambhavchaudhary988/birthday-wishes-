# 🎂 Happy Birthday Aunty

Starter project structure.

## Folder

- index.html
- style.css
- script.js
- images/

Rename your photos:

photo1.jpg
photo2.jpg
photo3.jpg
photo4.jpg
photo5.jpg
photo6.jpg

Place them in the images folder.
